public class Main {

    public static void main(String[] args) {

        LoginPage launchPage = new LoginPage();

    }
}
